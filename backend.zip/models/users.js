const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const saltRounds = 10;
const jwt = require('jsonwebtoken')

const Schema = mongoose.Schema;



const UsersSchema = new Schema({
  email: {
      type: String,
      required: true,
      unique: true,
      minlength: 4
  },
  password: {
      type: String,
      required: true,
      minlength: 4
  },
  registeredAt: {
      type: Date,
      default: new Date()
  },
  role: {
      type: String,
      enum: ['user', 'admin'],
      default: 'user'
  }
 });


UsersSchema.pre('save',  async function(next){
  console.log('Called before create method..... ****** ', this.password);
  console.log(this);
  this.password = await bcrypt.hash(this.password, saltRounds);
  next();
});


UsersSchema.methods.matchPasswords = async function(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password)
}


UsersSchema.methods.getSignedJwtToken = function(user) {
    const token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + (60 * 15),
        id: user._id,
        role: user.role
    }, `${process.env.JWT_SECRET}`);
    console.log(token)
    return token;

}

const Users = mongoose.model('Users', UsersSchema);

module.exports = Users;