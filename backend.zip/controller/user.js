const User = require('../models/users')
const path = require('path')
const asyncHandler = require('../middleware/async')


const register = asyncHandler(async (req, res, next) => {
   
    let user = await User.create(req.body);
    let token = user.getSignedJwtToken(user);
    res.status(201).json({ auth: true, token })
 

})


const login = asyncHandler(async (req, res, next) => {
    console.log(req.body)

    let { email, password } = req.body

    if (!email) return next({ status: 401,auth: false, message: 'Email is not provided' })

    let user = await User.findOne({ email });
    if (!user) return next({ status: 401,auth: false, message: 'Email provided is wrong!!' })

    let result = await user.matchPasswords(password);
    if (!result) return next({ status: 401, auth: false, message: 'Password provided is wrong!!' })

    let token = user.getSignedJwtToken(user);
    res.json({ auth: true, token })



})



const fetchAllUsers = asyncHandler(async (req, res) => {
      console.log(req.query)
     let users = await User.find().select(req.query.select).sort(req.query.sort);
     res.json({ success: true, data: users });
})


const delete1 =asyncHandler(async(req,res,next)=>{
    
     let result= await User.findByIdAndDelete({ _id: req.params.id}) 
       
         let user=await User.find();
            console.log(result)
        res.json({sucess: true,user:user })
      
    })


    const update=asyncHandler(async(req,res,next)=>{
        let user= await User.findByIdAndUpdate({ _id: req.params.id },req.body)
         
           res.json({sucess: true,data:user})
    
    
        })



        const findId=asyncHandler(async(req,res,next)=>{
           let users= await User.findById({ _id: req.params.id })
               
                 res.json({sucess: true,data: users})
          
          
              })
    

module.exports = { register, login, fetchAllUsers,delete1,update,findId}
