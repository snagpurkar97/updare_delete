const Workout = require('../models/workouts')
const asyncHandler = require('../middleware/async')


const findAllWorkouts = asyncHandler(async (req, res, next) => {
    res.json(res.advancedResults);
   
})
const findWorkoutByTitle = asyncHandler(async (req, res) => {
    console.log('In findWorkoutByTitle..')
   
        let workout = await Workout.findOne({ title: req.params.title });
        if (!workout) res.status(404).json({ success: false, message: `Workout by title ${req.params.title} not found` })

        res.json({ success: true, data: workout });

})

const delete1 =asyncHandler(async(req,res,next)=>{
    
    await Workout.deleteOne({ _id: req.params.id}) 
        
       res.json({sucess: true})
 
   })


module.exports = { findAllWorkouts, findWorkoutByTitle,delete1}
