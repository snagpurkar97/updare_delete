var express = require('express')
var router = express.Router()
const User = require('../models/users')
const {register, login, fetchAllUsers, delete1,update,findId} = require('../controller/user')
const {protect} = require('../middleware/auth')
const {advancedFind} = require('../middleware/advancedFind')
const { authorize } = require('../middleware/auth')

const loggerMiddleware = (req, res, next) =>{
    console.log('Request recieved: ', req.url)
    next();
}


router.route('/u')

.get(advancedFind(User),fetchAllUsers)

router.route('/register')
.post(register)

router.route('/login')
.post(login)

router.route('/:id')
.delete(delete1)

router.route('/u/:id')
.put(update)

router.route('/u/:id')
.get(findId)

module.exports = router;