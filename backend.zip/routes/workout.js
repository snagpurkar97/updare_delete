// workout routes
const Workout = require('../models/workouts')
var express = require('express')
var router = express.Router()

const {findAllWorkouts, findWorkoutByTitle, delete1} = require('../controller/workout')

const {protect, authorize} = require('../middleware/auth')
const { advancedFind } = require('../middleware/advancedFind')




router.route('/')
.get(protect,authorize('admin'), advancedFind(Workout, {path:'user', select: 'email '}),findAllWorkouts)


router.route('/:title')
.get(protect, findWorkoutByTitle)

router.route('/:id')
.delete(delete1)


module.exports = router;